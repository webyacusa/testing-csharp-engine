importPackage(Packages.com.filenet.api.collection);
importPackage(Packages.com.filenet.api.constants);
importPackage(Packages.com.filenet.api.admin);
importPackage(Packages.com.filenet.api.core);
importPackage(Packages.com.filenet.api.util);
importPackage(Packages.java.lang);

function PostImportScriptMethod(objectStore) 
{
    // Update the default instance permissions for each of the GenAI query
    // classes to remove any ACEs which grant less than full control. This
    // should leave only admins and the creator having access to instances.
    var cdQueryBase = Factory.ClassDefinition.fetchInstance(objectStore, "GenaiBaseQuery", null);
    UpdatePermissions ( cdQueryBase );
    
    // Put a unique index on the GenaiSummaryPromptDefinition.GenaiSummaryPromptClass property
    classDef = Factory.ClassDefinition.fetchInstance(objectStore, "GenaiClassSummaryGenerationDefinition", null);

    propDefs = classDef.get_PropertyDefinitions();
     
    for (i = 0; i < propDefs.size(); i++)
    {
        propDef = propDefs.get(i);
     
        // Locate column definition for GenaiSummaryPromptClass and create index
        if (propDef.get_SymbolicName().equals("GenaiSummaryPromptClass"))
        {            
            tblDef = propDef.get_TableDefinition();
            colDefs = tblDef.get_ColumnDefinitions();
     
            for (j = 0; j < colDefs.size(); j++)
            {
                colDef = colDefs.get(j);
                if (propDef.get_ColumnId().equals(colDef.get_Id()))
                {
                    indDefs = tblDef.get_IndexDefinitions();
                    indDef = Factory.CmIndexDefinition.createInstance();
                    indDefs.add(indDef);
                    
                    indDef.set_RequiresUniqueElements(java.lang.Boolean.TRUE);
                    indCols = Factory.CmIndexedColumn.createList();
                    indDef.set_IndexedColumns(indCols); 
                    
                    indCol = Factory.CmIndexedColumn.createInstance();          
                    indCol.set_ColumnName(colDef.get_ColumnName());
                    indCols.add(indCol);
                    
                    tblDef.save(RefreshMode.NO_REFRESH);
                    break;
                }
            }
        }
    }
}

function UpdatePermissions ( classDef )
{
    apl = classDef.get_DefaultInstancePermissions();
    
    for ( i = apl.size() - 1; i >= 0; i-- )
    {
        ap = apl.get(i);
        
        mask = ap.get_AccessMask().intValue();
                    
        if( (mask & AccessRight.WRITE_ACL_AS_INT) != AccessRight.WRITE_ACL_AS_INT )
        {
            // This access permission does not include WRITE_ACL -- remove it
            apl.remove(i);
        }
    }

    classDef.save ( RefreshMode.REFRESH );
    
    // Now recursively apply to subclasses
    xcds = classDef.get_ImmediateSubclassDefinitions();
    var iter1 = xcds.iterator();
    while(iter1.hasNext())
    {
        cdSub = iter1.next();
        UpdatePermissions ( cdSub );
    }
} 
